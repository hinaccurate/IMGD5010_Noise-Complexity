var honeybee = [];
var queenbee = [];

function setup() {
  createCanvas(400, 400);
  background("black");
  
  for (var i = 0; i < 200; i++){
    var x = random(width);
    var y = i + 100;
    var beecolor = "yellow"
    honeybee[i] = new Hive(x,y,beecolor);
  }
}

function draw() {
  for (var i=0; i < honeybee.length; i++){
    honeybee[i].display();
    honeybee[i].move();
  }
  for (var cell=0; cell < queenbee.length; cell++){
      queenbee[cell].display();
  }
}

function mousePressed() {
  var queencolor = "antiquewhite"
  var cellX = random(width);
  var cellY = random(height);
  queenbee.push(new QueenDaughter(cellX,cellY,queencolor));
}

function Hive(tempStartX,tempStartY,tempBeeColor){
  this.x = tempStartX;
  this.y = tempStartY;
  this.beecolor = tempBeeColor;
  this.speed = 2.5;
  this.diameter = 10;

  this.move = function(){
    this.x += random(-this.speed,this.speed);
    this.y += random(-this.speed,this.speed);
  };

  this.display = function(){
    ellipse(this.x,this.y,this.diameter,this.diameter);
    fill(this.beecolor);
  }
}

function QueenDaughter(beeX,beeY){
  this.cellX = beeX;
  this.cellY = beeY;
  this.diameter = 1;
  this.queencolor = "antiquewhite";
  
  this.display = function(){
    ellipse(this.cellX,this.cellY,this.diameter,this.diameter);
    fill(this.queencolor);
  }
}